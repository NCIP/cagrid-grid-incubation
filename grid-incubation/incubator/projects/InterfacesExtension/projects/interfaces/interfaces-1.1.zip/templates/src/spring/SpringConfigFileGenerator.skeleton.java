package edu.umn.msi.cagrid.introduce.interfaces.spring;

public class CLASS {

  public String generate() {
    return "";
  } 
}