package calc;

abstract public class Tracker {
    
  abstract public void setLastOp(String theLastOperation);

  abstract public String getLastOp();

}