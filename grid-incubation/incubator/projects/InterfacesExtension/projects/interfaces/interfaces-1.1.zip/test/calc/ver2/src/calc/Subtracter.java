package calc;

public interface Subtracter {
  public int subtract(int x, int y, String ticket);
}