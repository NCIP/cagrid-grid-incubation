package calc;

public class SubtracterImpl implements Subtracter {
  public int subtract(int x, int y) {
    return x - y;
  }
 
}

