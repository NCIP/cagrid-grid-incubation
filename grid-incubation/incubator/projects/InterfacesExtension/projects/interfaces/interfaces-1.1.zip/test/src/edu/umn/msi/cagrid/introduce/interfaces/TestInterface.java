package edu.umn.msi.cagrid.introduce.interfaces;

public interface TestInterface {
    public int foo();

    public String bar(int i, int j);
}