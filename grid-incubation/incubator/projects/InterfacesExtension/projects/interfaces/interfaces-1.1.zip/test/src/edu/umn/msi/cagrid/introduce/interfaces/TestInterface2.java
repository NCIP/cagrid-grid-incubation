package edu.umn.msi.cagrid.introduce.interfaces;

public interface TestInterface2 {
    public int foo2();

    public String bar2(int i, int j);
}