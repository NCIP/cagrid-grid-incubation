package edu.umn.msi.cagrid.introduce.interfaces;

public interface TestInterface3 {
    public void foo3();

    public String bar3(float x);
}