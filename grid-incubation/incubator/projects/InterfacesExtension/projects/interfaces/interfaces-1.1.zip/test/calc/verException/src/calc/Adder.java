package calc;

public interface Adder {
  public int add(int x, int y);
  public int add3(int x, int y, int z) throws Exception;
}