


public class AkwardTest extends AkwardBase {

  public AkwardTest() {
    super();
  }
  
    public void oneLine() { 1+2; }
    public void oneLineCondensed(){1+2;}
    public void topRun() { 1+2;
    }

    public void buttomRun() {
	1+2;}

    public void spread()
    {
	1+2;
    }
    
    public void badTab() {
1+2;
    } 
    
    public void badTabSpread() 
{
      1+2;
}

  public void two() {
    1+2;
  }

    public void four() {
        1+2;
    }
	public void tab() {
		1+2;
	}
}
