package calc;

public class AdderImpl implements Adder {
  public int add(int x, int y) {
    return x + y;
  }

  public int add3(int x, int y, int z) {
    return x + y + z;
  }
  
}

