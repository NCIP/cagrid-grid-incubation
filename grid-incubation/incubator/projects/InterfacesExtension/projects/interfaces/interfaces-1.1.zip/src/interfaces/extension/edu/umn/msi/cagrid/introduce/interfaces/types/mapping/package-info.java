/**
 * This package contains an interface and its implementation for turning
 * the type information provided in the edu.umn.msi.cagrid.introduce.interfaces.type
 * package into a function from Java classes to XML QNames.
 */
package edu.umn.msi.cagrid.introduce.interfaces.types.mapping;