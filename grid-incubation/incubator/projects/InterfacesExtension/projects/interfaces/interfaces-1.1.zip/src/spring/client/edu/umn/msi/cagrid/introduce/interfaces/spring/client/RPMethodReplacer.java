package edu.umn.msi.cagrid.introduce.interfaces.spring.client;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.globus.wsrf.Resource;
import org.globus.wsrf.ResourceContext;
import org.globus.wsrf.ResourceContextException;
import org.globus.wsrf.ResourceException;
import org.springframework.beans.factory.support.MethodReplacer;

public class RPMethodReplacer  implements MethodReplacer {
  private static final Logger logger = Logger.getLogger(RPMethodReplacer.class);
  private ResourceInfo resourceInfo;

  public Object reimplement(Object o, Method replacedMethod, Object[] args) {
    logger.debug("Replacing method " + replacedMethod.getName() + " on object " + o);
    return call(replacedMethod.getName(), args);
  }

  protected Object call(String beanMethodName, Object[] args) {
    //String resourcePropertyMethodName = methodNameMap.get(beanMethodName);
    String resourcePropertyMethodName = null;
    if(args == null || args.length == 0) {
      resourcePropertyMethodName = resourceInfo.getResourceGetterMethodName();
    } else {
      resourcePropertyMethodName = resourceInfo.getResourceSetterMethodName();
    }
    if(resourcePropertyMethodName == null) {
      throw new UnsupportedOperationException("Cannot find registered resource property for method " + beanMethodName);
    }
    Resource resource;
    try {
      resource = ResourceContext.getResourceContext().getResource();
    } catch (ResourceContextException e) {
      throw new IllegalStateException(e);
    } catch (ResourceException e) {
      throw new IllegalStateException(e);
    }
    Method resourcePropertyMethod;
    if(args.length > 0) {
      System.out.println("Arguement type of first arg is " + args[0].getClass().getCanonicalName());
    }
    try {
      if(args == null || args.length == 0) {
        resourcePropertyMethod = resource.getClass().getMethod(resourcePropertyMethodName);
      } else {
        resourcePropertyMethod = resource.getClass().getMethod(resourcePropertyMethodName, args[0].getClass());
      }
    } catch(NoSuchMethodException e) {
      throw new IllegalStateException("Mapped method does not exist",e);
    }

    try {
      if(args == null || args.length == 0) {
        return resourcePropertyMethod.invoke(resource);
      } else {
        resourcePropertyMethod.invoke(resource, args[0]);
        return null;
      }
    } catch (IllegalAccessException e) {
      throw new IllegalStateException(e);
    } catch (InvocationTargetException e) {
      // Shouldn't really happen, setters and getter don't throw any checked exceptions
      throw new IllegalStateException(e);
    }
  }

  public ResourceInfo getResourceInfo() {
    return resourceInfo;
  }

  public void setResourceInfo(ResourceInfo resourceInfo) {
    this.resourceInfo = resourceInfo;
  }

  
}
