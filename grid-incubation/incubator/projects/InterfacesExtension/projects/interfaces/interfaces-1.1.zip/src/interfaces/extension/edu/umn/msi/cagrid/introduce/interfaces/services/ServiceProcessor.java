package edu.umn.msi.cagrid.introduce.interfaces.services;


public interface ServiceProcessor {
  public void execute(Service service) throws Exception;

}

