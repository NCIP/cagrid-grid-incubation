/**
 * This package contains the annotation ImplementsForService for use
 * in Introduce generated service implementation files.
 */
package edu.umn.msi.cagrid.introduce.interfaces.client.service;
