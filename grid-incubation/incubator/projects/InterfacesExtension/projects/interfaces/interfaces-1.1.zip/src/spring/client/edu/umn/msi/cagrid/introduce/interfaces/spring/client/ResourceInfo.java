package edu.umn.msi.cagrid.introduce.interfaces.spring.client;

public class ResourceInfo {
  private String resource;
  private String bean;
  private String setter;
  private String getter;
  
  public String getResourceGetterMethodName() {
    return getGetterName(resource);
  }
  
  public String getResourceSetterMethodName() {
    return getSetterName(resource);
  }
  
  public String getBeanGetterMethodName() {
    if(getter != null) {
      return getter;
    } else if(bean != null) {
      return getGetterName(bean);
    } else {
      return null;
    }
  }
 
  public String getBeanSetterMethodName() {
    if(setter != null) {
      return setter;
    } else if(bean != null) {
      return getSetterName(bean);
    } else {
      return null;
    }
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }

  public String getBean() {
    return bean;
  }

  public void setBean(String bean) {
    this.bean = bean;
  }

  public String getSetter() {
    return setter;
  }

  public void setSetter(String setter) {
    this.setter = setter;
  }

  public String getGetter() {
    return getter;
  }

  public void setGetter(String getter) {
    this.getter = getter;
  }

    protected static String getSetterName(String propertyName) {
        return "set" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
    }
    
    protected static String getGetterName(String propertyName) {
        return "get" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
    }
}
