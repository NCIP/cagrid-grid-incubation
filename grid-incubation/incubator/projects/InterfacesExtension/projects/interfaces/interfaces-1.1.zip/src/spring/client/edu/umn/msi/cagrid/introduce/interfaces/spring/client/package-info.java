/**
 * This package contains the code actually used at Service runtime 
 * to implement Spring based resource properties. 
 */
package edu.umn.msi.cagrid.introduce.interfaces.spring.client;