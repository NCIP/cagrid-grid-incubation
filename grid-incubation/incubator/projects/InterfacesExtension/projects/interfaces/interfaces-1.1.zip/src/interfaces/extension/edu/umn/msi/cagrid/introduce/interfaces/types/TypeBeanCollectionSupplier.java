package edu.umn.msi.cagrid.introduce.interfaces.types;

import java.util.Collection;

import com.google.common.base.Supplier;

public interface TypeBeanCollectionSupplier extends Supplier<Collection<TypeBean>> {
}
