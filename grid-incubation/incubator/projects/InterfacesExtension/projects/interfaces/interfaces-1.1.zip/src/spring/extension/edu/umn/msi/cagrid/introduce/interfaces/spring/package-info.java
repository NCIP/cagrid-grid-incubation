/**
 * This package contains the implementation of the Spring 
 * Introduce extension. Introduce's entry-point is the Codegen
 * class, the other classes are support classes.
 */
package edu.umn.msi.cagrid.introduce.interfaces.spring;