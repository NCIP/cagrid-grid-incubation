package models

import play._

import org.apache.axis.message.addressing.EndpointReferenceType

import gov.nih.nci.cagrid.metadata.MetadataUtils
import gov.nih.nci.cagrid.metadata.ServiceMetadata
import gov.nih.nci.cagrid.metadata.common.PointOfContact

import scala.actors._
import scala.collection.immutable._
import scala.xml._

import java.io.File
import java.io.FileNotFoundException
import java.text.SimpleDateFormat
import java.util.Date

/** Class used as a message to the catalog to load its contents from a file. */
case class RequestLoadHistory(val fileName: String) {}

/** Class used as a message to the catalog to save its contents to a file. */
case class RequestSaveHistory(val fileName: String) {}

/**
** Catalog of known grid services.  It is also an actor that receive messages
** that are GridServiceDescription objects to be added to the catalog.
**/
object GridServiceCatalog extends Actor {
  private var catalog: Map[String, GridServiceDescription] = new TreeMap()

  private var lastUpdated: Option[Date] = None

  start()

  /**
  ** Receive messages that are GridServiceDescription objects and add them to the catalog.
  **/
  def act() {
    loop {
      react {
        case uniqueURLCounts: scala.collection.Map[String, Int] =>
	  update(uniqueURLCounts)

	case loadRequest: RequestLoadHistory =>
	  loadHistory(loadRequest.fileName)

	case saveRequest: RequestSaveHistory =>
	  saveHistory(saveRequest.fileName)

        case bug =>
          Logger.error("GridServiceCatalog was passed an unexpected type of  message: " + bug)
      }
    }
  }

  /**
  ** Update the given grid service catalog based on the presence of new URLs,
  ** and the absence of old URLs.
  **/
  private def update(uniqueURLCounts: scala.collection.Map[String, Int]) = {
    Logger.trace("Updating catalog");
    val now = new Date()
    uniqueURLCounts foreach {
      urlCountPair =>
      val (url, registrationCount) = urlCountPair
      catalog.get(url) match {
	case Some(description) =>  // update known services
	  Logger.trace("Updating description for url " + url + "; prev description status=" + description.status + "; comparison to NotRegistered is " + (description.status == RegistrationStatus.NotRegistered) + "; prev registration count=" + description.concurrentRegistrationCount + "; new registration count=" + Some(registrationCount))
	  if (description.status == RegistrationStatus.NotRegistered
	      || description.concurrentRegistrationCount!= Some(registrationCount)) {
	    Logger.trace("Adding new description for " + url)
	    val newDescription = GridServiceDescription(url, now, registrationCount, RegistrationStatus.Registered)
	    newDescription.previousDescription = Some(description)
	    catalog = catalog.update(url, newDescription)
	  }
	case None => // Add new services
	  Logger.trace("adding " + url)
	  catalog = catalog.update(url, GridServiceDescription(url, now, registrationCount))
      }
    }
    // find URLs that were not included in the latest discovery
    catalog.keySet foreach {
      url=>
      if (! uniqueURLCounts.contains(url)) {
        catalog.get(url) match {
	  case Some(description) =>
	    if (description.status == RegistrationStatus.Registered) {
	      val newDescription = GridServiceDescription(url, now, 0, RegistrationStatus.NotRegistered)
	      newDescription.previousDescription = Some(description)
	      catalog = catalog.update(url, newDescription)
	    }
	  case None =>
	    Logger.warn("URL unexpectedly disappeared from catalog: " + url);
	}
      }
    }
    lastUpdated = Some(now)
  }

  def descriptions(): scala.collection.Iterable[GridServiceDescription] = {
    catalog.values
  }

  def size = catalog.size

  def whenLastUpdated: Option[Date] = {
    lastUpdated
  }

  def get(url:String) = {
    catalog.get(url)
  }

  def catalogToXML(): Node = {
    val builder = NodeSeq.newBuilder
    catalog foreach {
      urlDescriptionPair =>
      val (url, description) = urlDescriptionPair
      builder += <service url={url}>{description.toXML()}</service>
    }
    val timestamp = whenLastUpdated match {
      case Some(date) => date
      case None => new Date()
    }
    val time = XMLFormats.DateFormat.format(timestamp)
    <catalog time={time}>{builder.result()}</catalog>
  }

  private def serviceNodeSeq(root: Node) = { root \ "service" }

  /**
  ** Populate this catalog from the given XML.
  ** @return the number of URLs for which the XML contain descriptions.
  **/
  def catalogFromXML(root:Node): Int = {
    val time = XMLFormats.DateFormat.parse((root \ "@time").text)
    val serviceSeq = serviceNodeSeq(root)
    var newCatalog: Map[String, GridServiceDescription] = new TreeMap()
    var urlCount = 0
    serviceSeq foreach {
      serviceXML =>
      val url = (serviceXML \ "@url").text
      val descriptionXML = (serviceXML \ "gridServiceDescription").first
      newCatalog = newCatalog.update(url, GridServiceDescription.fromXML(descriptionXML))
      urlCount += 1
    }
    lastUpdated = Some(time)
    catalog = newCatalog
    urlCount
  }

  /**
  ** Save the catalog and all of its historical information in a file with the given name.
  **/
  def saveHistory(historyFileName: String) {
    val historyFile = new File(historyFileName)
    Logger.info("Saving history to " + historyFile.getAbsolutePath());

    val newHistoryFileName = historyFileName + ".new"
    val newHistoryFile = new File(newHistoryFileName)
    val oldHistoryFileName = historyFileName + ".old"
    val oldHistoryFile = new File(oldHistoryFileName)
    val historyXML = catalogToXML()
    XML.save(newHistoryFileName, historyXML, "UTF-8", true)
    try {
      if (!oldHistoryFile.delete() && oldHistoryFile.exists()) {
        Logger.warn("Unable to delete " + oldHistoryFile.getAbsolutePath())
      } else if (!historyFile.renameTo(oldHistoryFile) && historyFile.exists()) {
        Logger.warn("Rename failed from " + historyFile.getAbsolutePath() + " to " + oldHistoryFile.getAbsolutePath())
      } else if (!newHistoryFile.renameTo(historyFile)) {
        Logger.warn("Rename failed from" + newHistoryFile.getAbsolutePath() + " to " + historyFile.getAbsolutePath())
      } else {
        Logger.info("Successful save of history for " + (serviceNodeSeq(historyXML).length) + " URLs")
      }
    } catch {
      case e: Exception =>
        val msg = "Error occurred while trying to rename " + newHistoryFile.getAbsolutePath() + " to " + historyFile.getAbsolutePath()
        Logger.error(msg, e)
    }
  }

  def loadHistory(historyFileName: String) {
    val historyFile = new File(historyFileName)
    Logger.info("Attempting to load history from " + historyFile.getAbsolutePath())
    try {
      val historyXML = try {
	XML.loadFile(historyFile)
      } catch {
        case e: FileNotFoundException =>
	  Logger.warn("Unable to open " + historyFile.getAbsolutePath())
	  return
	case e: Exception =>
	  val msg = "Error occurred while trying to load history from " + historyFile.getAbsolutePath()
	  Logger.error(msg, e)
	  return
      }
      val urlCount = GridServiceCatalog.catalogFromXML(historyXML)
      Logger.info("Successfully loaded descriptions for " + urlCount.toString + " URLs")
    } catch {
      case e: Throwable =>
        Logger.error("Error while loading history", e)
    }
  }
}

/**
** Case class to describe the known details of a grid service as of a point in time.
**
** @param urlString
**           The URL for accessing the service described by this object.
** @param creationTime
**           The time that this service information was obtained.
** @param concurrentRegistrationCount
**           The number of registrations for this service that existed in the index
**           service at the time this object was created, if known.
** @param status
**           Indicate whether the service url was currently registered with the
**           index service.
**/

case class GridServiceDescription private (val urlString: String,
                                           val creationTime: Date,
                                           val concurrentRegistrationCount: Option[Int],
					   val status: RegistrationStatus.Value) {
  // The previously created description for the described service.
  private[this] var myPreviousDescription:Option[GridServiceDescription] = None
  
  /**
  ** The previously created description for the service.
  **/
  def previousDescription = myPreviousDescription

  // allow the companion object to set the previous description for the described service.
  private[models] def previousDescription_=(prev: Option[GridServiceDescription]) {
    myPreviousDescription = prev
  }

  /**
  ** Create a GridServiceDescription similat to this one, but with status = RegistrationStatus.NotRegistered
  ** and having this GridServiceDescription as its previous description.
  **/
  def unregisteredDescription = {
    val unregisteredDesc = GridServiceDescription(urlString, new Date(), None, RegistrationStatus.NotRegistered)
    unregisteredDesc.previousDescription = Some(this)
    unregisteredDesc
  }

  private class registrationHistoryIterator extends Iterator[GridServiceDescription] {
    private var thisDescription: Option[GridServiceDescription] = Some(GridServiceDescription.this)

    def hasNext: Boolean = !thisDescription.isEmpty

    def next = {
      val nxt = thisDescription
      thisDescription = nxt.get.previousDescription
      nxt.get
    }
  }

  /**
  ** Return an iterator of this GridServiceDescription and each of its historical predecessors.
  **/
  def registrationHistory: Iterator[GridServiceDescription] = {
    new registrationHistoryIterator()
  }

  /**
  ** Return an XML representation of this object.
  **/
  def toXML() : Node = {
    val prev = myPreviousDescription match {
      case Some(description) =>
        List(description.toXML())
      case None =>
        Nil
    }
    val timeString = XMLFormats.DateFormat.format(creationTime)
    concurrentRegistrationCount match {
      case Some(count) =>  
        <gridServiceDescription url={urlString} time={timeString} count={count.toString} status={status.toString()}>{prev}</gridServiceDescription>

      case None =>
        <gridServiceDescription url={urlString} time={timeString} status={status.toString()}>{prev}</gridServiceDescription>
    }
  }

  /**
  ** Return the number of history events that for the service description that happened
  ** in the recent history period.
  **/
  def recentHistoryEventCount: Int = {
    val beginningOfRecentHistory = GridServiceDescription.currentBeginningOfRecentHistory
    val count = countEventsSince(beginningOfRecentHistory)
    if (Logger.isDebugEnabled()) {
      Logger.debug("Beginning of recent history: " + beginningOfRecentHistory.toString + "; creationTime: " + creationTime.toString + "; count: " + count.toString)
    }
    count
  }

  private def countEventsSince(beginningOfRecentHistory: Date): Int = {
    if (beginningOfRecentHistory.getTime() <= creationTime.getTime()) {
      myPreviousDescription match {
	case Some(description) =>
	  1 + description.countEventsSince(beginningOfRecentHistory)
	case None =>
	  1
      }
    } else {
      0
    }
  }
}

object GridServiceDescription {
  /**
  ** Construct a new GridServiceDescription object.
  **
  ** @param urlString
  **           A URL string for the service.
  ** @param captureTime
  **           The time that this information was captured.
  ** @param concurrentRegistrationCount
  **           The number of registrations for this service that existed in the index
  **           service at the time this object was created, if known.
  **/
  def apply(urlString: String, captureTime: Date, concurrentRegistrationCount: Int):GridServiceDescription = {
    apply(urlString, captureTime, concurrentRegistrationCount, RegistrationStatus.Registered)
  }
  def apply(urlString: String, captureTime: Date, concurrentRegistrationCount: Int, status: RegistrationStatus.Value):GridServiceDescription = {
    new GridServiceDescription(urlString, captureTime, Some(concurrentRegistrationCount), status)
  }

  def fromXML(root: Node): GridServiceDescription = {
    val predecessorXML = root \ "gridServiceDescription"
    val prev = predecessorXML.size match {
      case 1 =>
        Some(fromXML(predecessorXML.first))
      case _ =>
        None
    }
    val url = (root \ "@url").text
    val time = XMLFormats.DateFormat.parse((root \ "@time").text)
    val count = (root \ "@count").toList match {
      case List(countNode) =>
        Some(countNode.text.toInt)

      case List() =>
        None
    }
    val status = RegistrationStatus.withName( (root \ "@status").text )

    val descr = new GridServiceDescription(url, time, count, status)
    descr.previousDescription = prev
    descr
  }

  // The length in hours of the recent history period
  lazy val recentHistoryLength = Play.configuration.getProperty("indexMonitor.service1.recent_history.length").toInt

  /**
  ** The beginning of the recent history period, computed from the current time.
  **/
  def currentBeginningOfRecentHistory: Date = {
    val now = System.currentTimeMillis()
    val beginning = new Date(now - (recentHistoryLength * (60*60*1000)))
    beginning
  }
}

private[models] object XMLFormats {
  val DateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S");
}

object RegistrationStatus extends Enumeration {
  val Registered = Value("Registered")
  val NotRegistered = Value("Not Registered")
}