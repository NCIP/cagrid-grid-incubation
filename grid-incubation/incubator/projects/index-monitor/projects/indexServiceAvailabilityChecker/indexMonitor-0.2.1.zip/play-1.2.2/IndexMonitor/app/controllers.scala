package controllers

import play._
import play.mvc._

import discoveryJobs._
import models._

import java.util.Date

object Application extends Controller {
    
  import views.Application._

  def index = {
    Logger.trace("Entering controllers.Application.index")
    val serviceURL = Play.configuration.getProperty("indexMonitor.service1.display");
    val title =
      {if (serviceURL!=null)
	"Index Monitor for " + serviceURL
       else
	"Index Monitor (unconfigured)"
      }
    html.index(title, GridServiceCatalog.descriptions(), GridServiceCatalog.whenLastUpdated)
  }
}

object History extends Controller {
  import views.Application._

  def registration = {
    val request = Http.Request.current.get
    val params = request.params
    val serviceUrl = params.get("serviceUrl")
    val asOf = GridServiceCatalog.whenLastUpdated match {
      case Some(whenLastUpdated) =>
        whenLastUpdated
      case None =>
        new Date()
    }
    val history = GridServiceCatalog.get(serviceUrl) match {
      case Some(serviceDescription) =>
        serviceDescription.registrationHistory.toIterable
      case None =>
        Nil
    }
    html.registration(serviceUrl, history, asOf)
  }
}