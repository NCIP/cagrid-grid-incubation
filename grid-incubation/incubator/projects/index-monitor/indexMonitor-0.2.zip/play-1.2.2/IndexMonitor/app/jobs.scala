package discoveryJobs

import play._
import play.jobs._

import scala.collection.mutable._

import models._

import gov.nih.nci.cagrid.discovery.client._
import gov.nih.nci.cagrid.metadata.exceptions._

import org.apache.axis.message.addressing.EndpointReferenceType

abstract class DiscoveryJob extends Job {
  lazy val HistoryFileName = Play.configuration.getProperty("indexMonitor.service1.history_file")
  lazy val IndexServiceURL = Play.configuration.getProperty("indexMonitor.service1.url")

  def discover():Set[GridServiceDescription] = {
    val rawEndpoints = discoverServices()
    val uniqueURLCounts = countUniqueURLs(rawEndpoints)
    GridServiceCatalog ! uniqueURLCounts
    Logger.info("Discovery complete")
    new HashSet[GridServiceDescription]
  }

  private def discoverServices() = {
    Logger.info("Starting discovery using " + IndexServiceURL)
    val discoveryClient = new DiscoveryClient(IndexServiceURL)
    try {
      val rawEndpoints = discoveryClient.getAllServices(false)
      Logger.info("Discovered " + rawEndpoints.length + " endpoints")
      rawEndpoints
    } catch {
      case e: RemoteResourcePropertyRetrievalException =>
        val msg = "Error occurred while getting service information for the Index service. A possible cause is that $GLOBUS_LOCATION is not in the classpath."
	Logger.error(e, msg)
	throw new RuntimeException(msg, e)
    }
  }

  private def countUniqueURLs(endpoints: Array[EndpointReferenceType]): Map[String,Int] = {
    val urlCounts = new HashMap[String,Int]()
    endpoints foreach {
      endpoint =>
      val url = endpoint.getAddress().toString()
      urlCounts.get(url) match {
        case Some(count) =>
          urlCounts.update(url, count+1)				    
        case None =>
          urlCounts.put(url, 1)
      }
    }
    urlCounts
  }
}

@OnApplicationStart
class BootstrapDiscoveryJob extends DiscoveryJob {
  override def doJob() = {
    Logger.info("Recent history length is " + GridServiceDescription.recentHistoryLength + " hours")
    GridServiceCatalog ! RequestLoadHistory(HistoryFileName)
    Logger.info("Performing initial discovery");
    discover()
    GridServiceCatalog ! RequestSaveHistory(HistoryFileName)
  }
}
 
@Every("10mn")
class UpdateDiscoveryJob extends DiscoveryJob {
  override def doJob() = {
    Logger.info("Performing discovery for update");
    discover()
    GridServiceCatalog ! RequestSaveHistory(HistoryFileName)
  }
}
