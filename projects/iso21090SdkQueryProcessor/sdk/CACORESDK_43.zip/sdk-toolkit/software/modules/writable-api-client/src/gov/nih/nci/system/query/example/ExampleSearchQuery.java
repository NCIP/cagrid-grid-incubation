package gov.nih.nci.system.query.example;

import gov.nih.nci.system.query.SDKQuery;

public interface ExampleSearchQuery extends SDKQuery
{
}